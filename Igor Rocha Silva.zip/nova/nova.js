function Cumprimentar(){
    alert ("la ele amostradinho e a marcia: para de cer tao resseba calma calabreso 😂😂")
}

function Nome(){
    prompt ("insira seu nome: ")
}
function modoescuro(estado){
   if (estado == true){
    document.getElementById("corpinho").
    style.background = '#000'
    document.getElementById("corpo").
    style.color = '#2d6b22'

}   else{
    document.getElementById("corpinho").
    style.background = '#2d6b22'
    document.getElementById("corpo").
    style.color = '#2d6b22'
}

}

